package com.subham.reportchecks

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var store: Store
    private var selected: LocalDate = LocalDate.now()
    private val handler = Handler(Looper.getMainLooper())
    private val renderer = Renderer()
    private val accent = Color.parseColor("#E0A82E")
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    private lateinit var checksBox: LinearLayout
    private lateinit var dateLabel: TextView
    private lateinit var progress: TextView
    private lateinit var preview: ImageView
    private lateinit var paletteRow: LinearLayout
    private lateinit var editorBox: LinearLayout
    private lateinit var modeLabel: TextView
    private lateinit var tapSwitch: Switch

    private val applyRunnable = Runnable { applyStaticAsync(false) }
    private val refreshRunnable = Runnable { refreshChecks(); scheduleStatic() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        DailyReceiver.schedule(this)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        store.load()
        if (selected.isAfter(LocalDate.now())) selected = LocalDate.now()
        if (isLiveActive() && store.staticMode) { store.staticMode = false; store.save() }
        refreshAll()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun header(t: String) = TextView(this).apply {
        text = t; textSize = 20f; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(28), 0, dp(8))
    }

    private fun buildUi(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(48))
        }
        col.addView(TextView(this).apply { text = "Report checks"; textSize = 28f; typeface = Typeface.DEFAULT_BOLD })

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(4))
        }
        nav.addView(Button(this).apply {
            text = "‹"; textSize = 20f; contentDescription = "Previous day"
            setOnClickListener { selected = selected.minusDays(1); refreshChecks() }
        })
        dateLabel = TextView(this).apply {
            textSize = 17f; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, wrap, 1f)
        }
        nav.addView(dateLabel)
        nav.addView(Button(this).apply {
            text = "›"; textSize = 20f; contentDescription = "Next day"
            setOnClickListener {
                if (selected.isBefore(LocalDate.now())) { selected = selected.plusDays(1); refreshChecks() }
            }
        })
        col.addView(nav)

        checksBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(checksBox)
        progress = TextView(this).apply { setPadding(dp(4), dp(6), 0, 0); alpha = .75f }
        col.addView(progress)

        col.addView(header("Wallpaper"))
        preview = ImageView(this).apply {
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(dp(180), wrap).apply {
                gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(14)
            }
        }
        col.addView(preview)
        paletteRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_HORIZONTAL
        }
        col.addView(paletteRow)
        col.addView(Button(this).apply {
            text = "Set live wallpaper (updates instantly)"
            setOnClickListener { setLive() }
        })
        col.addView(Button(this).apply {
            text = "Set static wallpaper (home + lock screen)"
            setOnClickListener { store.staticMode = true; store.save(); applyStaticAsync(true) }
        })
        tapSwitch = Switch(this).apply {
            text = "Tap a check on the home screen to tick it (live wallpaper only)"
            setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, v -> store.tapToTick = v; store.save() }
        }
        col.addView(tapSwitch)
        modeLabel = TextView(this).apply { textSize = 13f; alpha = .7f }
        col.addView(modeLabel)

        col.addView(header("Edit checklist"))
        editorBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(editorBox)
        col.addView(Button(this).apply {
            text = "Add a check"
            setOnClickListener {
                store.items.add(Item(System.currentTimeMillis().toString(36), "New check"))
                changed(); buildEditor(focusLast = true)
            }
        })

        return ScrollView(this).apply {
            isFillViewport = true
            addView(col, ViewGroup.LayoutParams(match, wrap))
        }
    }

    private fun refreshAll() {
        tapSwitch.isChecked = store.tapToTick
        buildPalettes(); refreshChecks(); buildEditor(); refreshMode()
    }

    private fun refreshChecks() {
        val today = LocalDate.now()
        dateLabel.text = if (selected == today) "Today"
            else selected.format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale.ENGLISH))
        checksBox.removeAllViews()
        val done = store.doneFor(selected)
        store.items.forEach { item ->
            checksBox.addView(CheckBox(this).apply {
                text = item.name; textSize = 18f
                isChecked = item.id in done
                buttonTintList = ColorStateList.valueOf(accent)
                setPadding(dp(8), dp(12), 0, dp(12))
                setOnCheckedChangeListener { _, _ -> store.toggle(selected, item.id); changed() }
            })
        }
        progress.text = if (store.items.isEmpty()) "Add a check below to get started."
            else "${done.size} of ${store.items.size} done"
        refreshPreview()
    }

    private fun refreshPreview() {
        val (w, h) = Renderer.screenSize(this)
        val pw = 540
        preview.setImageBitmap(renderer.bitmap(store, pw, pw * h / w))
    }

    private fun buildPalettes() {
        paletteRow.removeAllViews()
        Palettes.all.forEach { (name, p) ->
            val v = View(this)
            v.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(p.bg, p.bg, p.done)
            ).apply {
                shape = GradientDrawable.OVAL
                if (store.palette == name) setStroke(dp(3), Color.GRAY)
            }
            v.layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply {
                setMargins(dp(8), 0, dp(8), dp(14))
            }
            v.contentDescription = "$name colours"
            v.setOnClickListener { store.palette = name; changed(); buildPalettes() }
            paletteRow.addView(v)
        }
    }

    private fun buildEditor(focusLast: Boolean = false) {
        editorBox.removeAllViews()
        store.items.forEachIndexed { idx, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            }
            val et = EditText(this).apply {
                setText(item.name); setSingleLine(true)
                layoutParams = LinearLayout.LayoutParams(0, wrap, 1f)
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) {
                        val n = s?.toString()?.trim().orEmpty()
                        if (n.isNotEmpty() && n != item.name) {
                            item.name = n; store.save()
                            handler.removeCallbacks(refreshRunnable)
                            handler.postDelayed(refreshRunnable, 500)
                        }
                    }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                })
            }
            row.addView(et)
            row.addView(Button(this).apply {
                text = "✕"; contentDescription = "Remove ${item.name}"
                setOnClickListener { store.items.remove(item); changed(); buildEditor() }
            })
            editorBox.addView(row)
            if (focusLast && idx == store.items.lastIndex) { et.requestFocus(); et.selectAll() }
        }
    }

    private fun changed() {
        store.save()
        refreshChecks()
        scheduleStatic()
    }

    private fun scheduleStatic() {
        if (!store.staticMode) return
        handler.removeCallbacks(applyRunnable)
        handler.postDelayed(applyRunnable, 1500)
    }

    private fun isLiveActive(): Boolean =
        WallpaperManager.getInstance(this).wallpaperInfo?.packageName == packageName

    private fun setLive() {
        store.staticMode = false; store.save()
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, CheckWallpaperService::class.java)
        )
        try { startActivity(i) } catch (e: Exception) {
            try { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) } catch (e2: Exception) {
                toast("Open Settings, then Wallpaper, and choose Report checks")
            }
        }
    }

    private fun applyStaticAsync(announce: Boolean) {
        Thread {
            val ok = try { Renderer.applyStatic(applicationContext); true } catch (e: Exception) { false }
            runOnUiThread {
                if (announce) toast(if (ok) "Wallpaper set on home and lock screen" else "Couldn't set the wallpaper")
                refreshMode()
            }
        }.start()
    }

    private fun refreshMode() {
        modeLabel.text = when {
            isLiveActive() -> "Live wallpaper is on. It updates as soon as you tick."
            store.staticMode -> "Static wallpaper is on. It refreshes when you edit here and once a day after midnight."
            else -> "No wallpaper set yet. Pick live or static above."
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
