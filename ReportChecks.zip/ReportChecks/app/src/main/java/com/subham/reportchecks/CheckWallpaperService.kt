package com.subham.reportchecks

import android.app.WallpaperManager
import android.content.SharedPreferences
import android.graphics.Canvas
import android.os.Bundle
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.time.LocalDate

/** Live wallpaper: redraws whenever the checklist changes or the screen comes on. */
class CheckWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = CheckEngine()

    inner class CheckEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener {
        private lateinit var store: Store
        private val renderer = Renderer()
        private var visible = false

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            store = Store(applicationContext)
            store.prefs.registerOnSharedPreferenceChangeListener(this)
        }

        override fun onDestroy() {
            store.prefs.unregisterOnSharedPreferenceChangeListener(this)
            super.onDestroy()
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) { store.load(); draw() }   // also picks up a new day
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            draw()
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) {
            super.onSurfaceRedrawNeeded(holder)
            draw()
        }

        override fun onSharedPreferenceChanged(p: SharedPreferences?, key: String?) {
            store.load()
            if (visible) draw()
        }

        override fun onCommand(
            action: String?, x: Int, y: Int, z: Int, extras: Bundle?, resultRequested: Boolean
        ): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP && store.tapToTick) {
                renderer.hitTest(x.toFloat(), y.toFloat())?.let { store.toggle(LocalDate.now(), it) }
            }
            return super.onCommand(action, x, y, z, extras, resultRequested)
        }

        private fun draw() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = holder.lockCanvas()
                if (c != null) renderer.draw(c, store, c.width, c.height)
            } catch (_: Exception) {
            } finally {
                if (c != null) try { holder.unlockCanvasAndPost(c) } catch (_: Exception) {}
            }
        }
    }
}
