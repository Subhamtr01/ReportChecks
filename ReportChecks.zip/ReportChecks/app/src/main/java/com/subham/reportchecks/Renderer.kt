package com.subham.reportchecks

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.text.TextPaint
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Display
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class Palette(
    val bg: Int, val bg2: Int, val ink: Int, val muted: Int,
    val empty: Int, val part: Int, val done: Int, val doneInk: Int
)

object Palettes {
    private fun c(s: String) = Color.parseColor(s)
    val all = linkedMapOf(
        "pine" to Palette(c("#16302F"), c("#1E3F3D"), c("#E8F0EC"), c("#7F9C97"), c("#2A4A48"), c("#5E8C80"), c("#F2C14E"), c("#2A1F05")),
        "indigo" to Palette(c("#1C1F3F"), c("#262A55"), c("#ECECF7"), c("#8A8CB5"), c("#30345F"), c("#6C70B0"), c("#7EE0C3"), c("#0E2A22")),
        "plum" to Palette(c("#2E1A2C"), c("#3D2339"), c("#F5E9F1"), c("#A98AA0"), c("#46293F"), c("#8E5D7F"), c("#FFB38A"), c("#3A1A08")),
        "daylight" to Palette(c("#E9F0EC"), c("#DCE7E1"), c("#16302F"), c("#64807A"), c("#CBDAD3"), c("#93BBAC"), c("#16302F"), c("#F2C14E"))
    )
    fun get(name: String): Palette = all[name] ?: all.getValue("pine")
}

/** Draws the wallpaper. Layout is designed on a 1080-wide canvas and scaled to the screen. */
class Renderer {
    private val rowHits = mutableListOf<Pair<RectF, String>>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val bold = Typeface.create("sans-serif", Typeface.BOLD)
    private val medium = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val regular = Typeface.create("sans-serif", Typeface.NORMAL)

    /** Returns the id of the checklist row at screen position (x, y), if any. */
    fun hitTest(x: Float, y: Float): String? = synchronized(rowHits) {
        rowHits.firstOrNull { it.first.contains(x, y) }?.second
    }

    fun bitmap(store: Store, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        draw(Canvas(b), store, w, h)
        return b
    }

    fun draw(canvas: Canvas, store: Store, w: Int, h: Int) {
        val p = Palettes.get(store.palette)
        val s = w / 1080f
        val dh = h / s
        val today = LocalDate.now()

        canvas.save()
        canvas.scale(s, s)
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, 0f, 0f, dh, p.bg, p.bg2, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, 1080f, dh, paint)
        paint.shader = null

        // Month + streak (sits below the lock-screen clock)
        val mx = 96f
        val y0 = dh * 0.376f
        text.textAlign = Paint.Align.LEFT
        text.color = p.ink; text.typeface = bold; text.textSize = 84f
        canvas.drawText(today.month.getDisplayName(TextStyle.FULL, Locale.ENGLISH), mx, y0, text)
        val st = store.streak()
        text.color = p.muted; text.typeface = medium; text.textSize = 40f
        canvas.drawText(if (st > 0) "$st day streak" else "Start today", mx, y0 + 62f, text)

        // Calendar
        val gy = y0 + 130f
        val gw = 1080f - mx * 2
        val cell = gw / 7f
        val r = cell * 0.36f
        text.textAlign = Paint.Align.CENTER; text.textSize = 30f; text.color = p.muted
        listOf("M", "T", "W", "T", "F", "S", "S").forEachIndexed { i, d ->
            canvas.drawText(d, mx + cell * i + cell / 2, gy, text)
        }
        val firstDay = today.withDayOfMonth(1)
        val first = firstDay.dayOfWeek.value - 1
        val last = today.lengthOfMonth()
        val total = max(store.items.size, 1)
        for (i in 1..last) {
            val idx = first + i - 1
            val cx = mx + cell * (idx % 7) + cell / 2
            val cy = gy + 50f + (idx / 7) * cell + cell / 2 - 10f
            val d = firstDay.withDayOfMonth(i)
            when (val stt = store.status(d)) {
                DayStatus.FULL -> {
                    paint.style = Paint.Style.FILL; paint.color = p.done
                    canvas.drawCircle(cx, cy, r, paint)
                    tick(canvas, cx, cy, r * 1.15f, p.doneInk, 9f)
                }
                else -> {
                    paint.style = Paint.Style.FILL; paint.color = p.empty
                    canvas.drawCircle(cx, cy, r, paint)
                    if (stt == DayStatus.PART) {
                        val f = store.doneFor(d).size.toFloat() / total
                        paint.style = Paint.Style.STROKE; paint.strokeWidth = 8f
                        paint.strokeCap = Paint.Cap.ROUND; paint.color = p.done
                        canvas.drawArc(RectF(cx - r + 4, cy - r + 4, cx + r - 4, cy + r - 4), -90f, 360f * f, false, paint)
                        paint.style = Paint.Style.FILL
                    }
                    text.typeface = medium; text.textSize = 32f
                    text.color = if (stt == DayStatus.FUTURE) p.muted else p.ink
                    text.alpha = if (stt == DayStatus.FUTURE) 140 else 255
                    val fm = text.fontMetrics
                    canvas.drawText("$i", cx, cy - (fm.ascent + fm.descent) / 2, text)
                    text.alpha = 255
                }
            }
            if (d == today) {
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 4f; paint.color = p.ink
                canvas.drawCircle(cx, cy, r + 9f, paint)
                paint.style = Paint.Style.FILL
            }
        }
        val rows = (first + last + 6) / 7

        // Today's checklist card
        val ly = gy + 50f + rows * cell + 60f
        val items = store.items.take(6)
        val doneT = store.doneFor(today)
        val ch = items.size * 92f + 120f
        paint.style = Paint.Style.FILL; paint.color = p.empty; paint.alpha = 140
        canvas.drawRoundRect(RectF(mx - 24, ly, mx + gw + 24, ly + ch), 44f, 44f, paint)
        paint.alpha = 255
        text.textAlign = Paint.Align.LEFT
        text.color = p.muted; text.typeface = medium; text.textSize = 34f
        canvas.drawText("Daily checks", mx + 16, ly + 66, text)

        val hits = mutableListOf<Pair<RectF, String>>()
        items.forEachIndexed { i, it ->
            val iy = ly + 112f + i * 92f
            val on = it.id in doneT
            if (on) {
                paint.style = Paint.Style.FILL; paint.color = p.done
                canvas.drawRoundRect(RectF(mx + 16, iy, mx + 70, iy + 54), 14f, 14f, paint)
                tick(canvas, mx + 43, iy + 27, 40f, p.doneInk, 7f)
            } else {
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 4f; paint.color = p.muted
                canvas.drawRoundRect(RectF(mx + 18, iy + 2, mx + 68, iy + 52), 13f, 13f, paint)
                paint.style = Paint.Style.FILL
            }
            text.color = if (on) p.muted else p.ink
            text.typeface = regular; text.textSize = 40f
            val label = TextUtils.ellipsize(it.name, text, gw - 130f, TextUtils.TruncateAt.END).toString()
            canvas.drawText(label, mx + 100, iy + 42, text)
            hits.add(RectF((mx - 24) * s, (iy - 19) * s, (mx + gw + 24) * s, (iy + 73) * s) to it.id)
        }
        synchronized(rowHits) { rowHits.clear(); rowHits.addAll(hits) }
        canvas.restore()
    }

    private fun tick(c: Canvas, cx: Float, cy: Float, sz: Float, color: Int, lw: Float) {
        paint.style = Paint.Style.STROKE; paint.color = color; paint.strokeWidth = lw
        paint.strokeCap = Paint.Cap.ROUND; paint.strokeJoin = Paint.Join.ROUND
        val path = Path().apply {
            moveTo(cx - sz * .42f, cy + sz * .02f)
            lineTo(cx - sz * .12f, cy + sz * .32f)
            lineTo(cx + sz * .45f, cy - sz * .3f)
        }
        c.drawPath(path, paint)
        paint.style = Paint.Style.FILL
    }

    companion object {
        fun screenSize(ctx: Context): Pair<Int, Int> {
            val dm = DisplayMetrics()
            val dmgr = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            @Suppress("DEPRECATION")
            dmgr.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
            return min(dm.widthPixels, dm.heightPixels) to max(dm.widthPixels, dm.heightPixels)
        }

        /** Sets a static image on both home and lock screen. Call off the main thread. */
        fun applyStatic(ctx: Context) {
            val store = Store(ctx)
            val (w, h) = screenSize(ctx)
            val bmp = Renderer().bitmap(store, w, h)
            WallpaperManager.getInstance(ctx).setBitmap(
                bmp, null, true, WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            )
        }
    }
}
