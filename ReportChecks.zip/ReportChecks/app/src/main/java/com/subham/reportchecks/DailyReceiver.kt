package com.subham.reportchecks

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDate
import java.time.ZoneId

/** Refreshes the static wallpaper just after midnight, and re-arms after a reboot. */
class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) schedule(ctx)
        if (!Store(ctx).staticMode) return
        val pending = goAsync()
        Thread {
            try { Renderer.applyStatic(ctx) } catch (_: Exception) {} finally { pending.finish() }
        }.start()
    }

    companion object {
        fun schedule(ctx: Context) {
            val am = ctx.getSystemService(AlarmManager::class.java) ?: return
            val pi = PendingIntent.getBroadcast(
                ctx, 1, Intent(ctx, DailyReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val next = LocalDate.now().plusDays(1).atTime(0, 5)
                .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            am.setInexactRepeating(AlarmManager.RTC, next, AlarmManager.INTERVAL_DAY, pi)
        }
    }
}
