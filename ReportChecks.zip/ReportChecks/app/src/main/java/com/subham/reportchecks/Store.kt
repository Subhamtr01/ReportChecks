package com.subham.reportchecks

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate

data class Item(val id: String, var name: String)

enum class DayStatus { FULL, PART, NONE, FUTURE }

/** All tracker data, kept in SharedPreferences as one JSON blob. */
class Store(context: Context) {
    val prefs: SharedPreferences = context.getSharedPreferences("tracker", Context.MODE_PRIVATE)
    val items = mutableListOf<Item>()
    val ticks = mutableMapOf<String, MutableSet<String>>()
    var palette = "pine"
    var tapToTick = true
    var staticMode = false
    /** 0 = no photo; otherwise changes each time a new photo is chosen. */
    var bgVersion = 0L
    /** How much to darken the photo, 0-90 (%). */
    var bgDim = 50
    val bgFile = File(context.filesDir, "bg.jpg")
    val hasBg get() = bgVersion > 0L && bgFile.exists()

    init { load() }

    fun load() {
        items.clear(); ticks.clear()
        val raw = prefs.getString(KEY, null)
        if (raw == null) { loadDefaults(); return }
        try {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("items") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val it = arr.getJSONObject(i)
                items.add(Item(it.getString("id"), it.getString("name")))
            }
            val t = o.optJSONObject("ticks") ?: JSONObject()
            val keys = t.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val a = t.getJSONArray(k)
                val set = mutableSetOf<String>()
                for (i in 0 until a.length()) set.add(a.getString(i))
                ticks[k] = set
            }
            palette = o.optString("palette", "pine")
            tapToTick = o.optBoolean("tap", true)
            staticMode = o.optBoolean("static", false)
            bgVersion = o.optLong("bgVersion", 0L)
            bgDim = o.optInt("bgDim", 50)
        } catch (e: Exception) {
            items.clear(); ticks.clear(); loadDefaults()
        }
    }

    private fun loadDefaults() {
        DEFAULT_ITEMS.forEachIndexed { i, n -> items.add(Item("d$i", n)) }
    }

    fun save() {
        val o = JSONObject()
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name)) }
        o.put("items", arr)
        val t = JSONObject()
        ticks.forEach { (k, v) -> if (v.isNotEmpty()) t.put(k, JSONArray(v.toList())) }
        o.put("ticks", t)
        o.put("palette", palette)
        o.put("tap", tapToTick)
        o.put("static", staticMode)
        o.put("bgVersion", bgVersion)
        o.put("bgDim", bgDim)
        prefs.edit().putString(KEY, o.toString()).apply()
    }

    fun doneFor(date: LocalDate): Set<String> {
        val ids = items.map { it.id }.toSet()
        return (ticks[date.toString()] ?: emptySet<String>()).filter { it in ids }.toSet()
    }

    fun toggle(date: LocalDate, id: String) {
        val set = ticks.getOrPut(date.toString()) { mutableSetOf() }
        if (!set.remove(id)) set.add(id)
        save()
    }

    fun status(date: LocalDate): DayStatus {
        if (date.isAfter(LocalDate.now())) return DayStatus.FUTURE
        val n = doneFor(date).size
        return when {
            items.isNotEmpty() && n >= items.size -> DayStatus.FULL
            n > 0 -> DayStatus.PART
            else -> DayStatus.NONE
        }
    }

    fun streak(): Int {
        var d = LocalDate.now()
        if (status(d) != DayStatus.FULL) d = d.minusDays(1)
        var s = 0
        while (status(d) == DayStatus.FULL && s < 3660) { s++; d = d.minusDays(1) }
        return s
    }

    companion object {
        const val KEY = "data"
        val DEFAULT_ITEMS = listOf(
            "DOD target vs actual",
            "Lead distribution check",
            "Airflow DAG run status",
            "City-wise bookings review"
        )
    }
}
