# Report checks (Android)

Daily report checklist that lives on your wallpaper.

- Live wallpaper redraws the moment you tick or edit a check; tap checks on the home screen to tick them.
- Static mode sets the image on home and lock screen, refreshing on every edit and once a day.
- Pick any gallery photo as the background and choose how much to darken it.

Build on GitHub: upload ReportChecks.zip plus .github/workflows/build.yml (unzip version), then download ReportChecks-apk from Actions.
From version 1.1 the app is signed with a fixed key (app/reportchecks.keystore), so new builds install as updates and keep your data.
