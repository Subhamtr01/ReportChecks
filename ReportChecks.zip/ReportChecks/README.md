# Report checks (Android)

Daily report checklist that lives on your wallpaper.

- Live wallpaper redraws the moment you tick or edit a check, and you can tick checks by tapping them on the home screen.
- Static mode sets the image on home and lock screen, refreshing on every edit and once a day.

## Build without a computer setup (GitHub)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab, then the **Build APK** run, and wait about 5 minutes.
3. Download **ReportChecks-apk** from the run, unzip it on your phone, and open `app-debug.apk`.

## Build with Android Studio
Open this folder in Android Studio, let Gradle sync, then Run on your phone (USB debugging on) or Build > Build APK(s).
